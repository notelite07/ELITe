const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'interactionCreate',
    async execute(interaction) {
        if (!interaction.isStringSelectMenu()) return;

        if (interaction.customId === 'help_menu') {
            let embed = new EmbedBuilder().setColor('Blue');

            if (interaction.values[0] === 'moderation') {
                embed.setTitle('🔨 Moderation Commands')
                    .setDescription('`ban`, `unban`, `mute`, `unmute`, `kick`, `purge`');
            } else if (interaction.values[0] === 'utilities') {
                embed.setTitle('🛠️ Utility Commands')
                    .setDescription('`ping`, `serverinfo`, `userinfo`, `avatar`');
            } else if (interaction.values[0] === 'other') {
                embed.setTitle('✨ Other Commands')
                    .setDescription('`poll`, `remind`');
            }

            await interaction.update({ embeds: [embed], components: [] });
        }
    }
};
