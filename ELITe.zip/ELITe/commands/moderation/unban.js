const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('unban')
        .setDescription('Unbans a user by ID')
        .addStringOption(option => option.setName('userid').setDescription('The user ID to unban').setRequired(true))
        .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers),

    async execute(interaction) {
        const userId = interaction.options.getString('userid');

        try {
            await interaction.guild.bans.remove(userId);
            await interaction.reply({ content: `Successfully unbanned <@${userId}>.` });
        } catch (error) {
            await interaction.reply({ content: 'Failed to unban user. Ensure the ID is correct.', ephemeral: true });
        }
    }
};
