const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('userinfo')
        .setDescription('Displays user information')
        .addUserOption(option => option.setName('target').setDescription('The user').setRequired(false)),

    async execute(interaction) {
        const user = interaction.options.getUser('target') || interaction.user;
        await interaction.reply(`Username: ${user.username}\nID: ${user.id}`);
    }
};
