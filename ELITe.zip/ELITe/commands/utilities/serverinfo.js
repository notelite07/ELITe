const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('serverinfo')
        .setDescription('Displays server information'),

    async execute(interaction) {
        const { guild } = interaction;
        await interaction.reply(`Server Name: ${guild.name}\nTotal Members: ${guild.memberCount}`);
    }
};
