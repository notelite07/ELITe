const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('remind')
        .setDescription('Sets a reminder')
        .addStringOption(option => option.setName('message').setDescription('Reminder message').setRequired(true)),

    async execute(interaction) {
        const message = interaction.options.getString('message');
        await interaction.reply(`Reminder set: ${message}`);
    }
};
