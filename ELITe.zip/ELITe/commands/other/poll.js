const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('poll')
        .setDescription('Creates a poll')
        .addStringOption(option => option.setName('question').setDescription('Poll question').setRequired(true)),

    async execute(interaction) {
        const question = interaction.options.getString('question');
        const message = await interaction.reply({ content: `📊 **Poll:** ${question}`, fetchReply: true });

        await message.react('👍');
        await message.react('👎');
    }
};
