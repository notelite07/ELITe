const { SlashCommandBuilder, ActionRowBuilder, StringSelectMenuBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('help')
        .setDescription('Displays a help menu with commands.'),

    async execute(interaction) {
        // Define command categories
        const categories = {
            moderation: ['ban', 'unban', 'mute', 'unmute', 'kick', 'purge'],
            utilities: ['ping', 'serverinfo', 'userinfo', 'avatar'],
            other: ['poll', 'remind']
        };

        // Create the dropdown menu
        const selectMenu = new StringSelectMenuBuilder()
            .setCustomId('help_menu')
            .setPlaceholder('Select a command category')
            .addOptions([
                { label: 'Moderation', description: 'Commands for moderating the server.', value: 'moderation' },
                { label: 'Utilities', description: 'Helpful utility commands.', value: 'utilities' },
                { label: 'Other', description: 'Miscellaneous commands.', value: 'other' }
            ]);

        const row = new ActionRowBuilder().addComponents(selectMenu);

        // Create an embed
        const embed = new EmbedBuilder()
            .setTitle('Help Menu')
            .setDescription('Use the dropdown menu below to view available commands.')
            .setColor('Blue');

        await interaction.reply({ embeds: [embed], components: [row], ephemeral: true });
    }
};
